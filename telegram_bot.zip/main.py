
import telebot
from telebot import types

# إعدادات البوت
BOT_TOKEN = "7900541512:AAHiGwRmF_Qs9B7epZKCRr4g8lXU7_z30DM"
CHANNEL_USERNAME = "ll_C_W"
DEVELOPER_USERNAME = "ll_Q_Y"

bot = telebot.TeleBot(BOT_TOKEN)
user_data = {}
message_counter = {}

# التحقق من الاشتراك في القناة
def is_user_subscribed(user_id):
    try:
        status = bot.get_chat_member(f"@{CHANNEL_USERNAME}", user_id).status
        return status in ['member', 'administrator', 'creator']
    except Exception:
        return False

# أمر /start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    if not is_user_subscribed(user_id):
        markup = types.InlineKeyboardMarkup()
        btn = types.InlineKeyboardButton("اشترك في القناة", url=f"https://t.me/{CHANNEL_USERNAME}")
        markup.add(btn)
        bot.reply_to(message, "اشترك في القناة أولاً للاستمرار.", reply_markup=markup)
        return

    # عداد الرسائل
    if user_id in message_counter:
        message_counter[user_id] += 1
    else:
        message_counter[user_id] = 1

    # رسالة الترحيب
    markup = types.InlineKeyboardMarkup()
    dev_btn = types.InlineKeyboardButton("المطور", url=f"https://t.me/{DEVELOPER_USERNAME}")
    markup.add(dev_btn)
    bot.reply_to(message, f"أهلاً بك في البوت!
عدد رسائلك: {message_counter[user_id]}", reply_markup=markup)

# تشغيل البوت
bot.infinity_polling()
