<?php

function command_ping(){
    sendMessage("pong!");
}

function command_start(){
    sendMessage("test 11 test");
}
