<?php
$TOKEN = ""; // bot token
$botUsername = ""; // bot username without @

/*
$databaseHost = "localhost";
$databaseName = ""; // db name
$databaseUsername = ""; // db username
$databasePassword = ""; // db password
*/

$sudoID = ""; // sudo id

date_default_timezone_set("Asia/Riyadh");
